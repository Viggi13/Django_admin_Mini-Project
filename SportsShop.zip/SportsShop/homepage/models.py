from django.db import models

# Create your models here.
class Sport(models.Model):
    name=models.CharField(max_length=100)
    picture=models.ImageField()
    equipmentName=models.CharField(max_length=100)
    quantity=models.IntegerField()

    def __str__(self):
        result=self.name+" has taken "+self.equipmentName
        return result 

    class Meta:
        db_table="sports"